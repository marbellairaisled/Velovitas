<?php
if (has_nav_menu('primary')) {
    wp_nav_menu(array(
        'theme_location' => 'primary',
        'menu_class' => 'primary-menu', 
    ));
}
?>


<?php

get_header();
?>
<head>

</head>


<main class="wrap">
    <center>
          <h1 class"h1">Headline of Website Will Goes Here in Two Line and Centered</h1>
    <h5>Lorem ipsum dolor sit amet consectetur. Elementum risus tempor at vivamus curabitur viverra diam nec.</h5>
        <br>

<!-- Button trigger modal -->
<button type="button" class="btn btn-secondary" data-bs-toggle="modal" data-bs-target="#exampleModal">
  Button
</button>

<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="exampleModalLabel">Modal title</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        ...
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary">Save changes</button>
      </div>
    </div>
  </div>
</div>


    <br>
    <img src="https://velovitaoffers.com/cdn/shop/files/vv-fullColor-RGB.png?height=628&pad_color=ffffff&v=1704830655&width=1200" class="img-fluid" alt="..." >
    <br>
     
<style>
    
    .custom-column
    {

    
    }
</style>
 
        <h1>Headline of Website Will Goes Here in Two Line and Centered</h1>
        
    </center>
    <div class="container text-center">
   <div class="row align-items-center justify-content-center">
    <div class="col-md custom-column">
<img src="https://velovita.com/wp-content/uploads/2024/05/member-rewards-scaled.webp" class="img-fluid" alt="..." style="border-radius: 5%; width: 522px; height: 522px; object-fit: cover;">
    </div>
      
      
      <div class="col-md custom-column">

    <div class="container text-center">
  
<div class="container text-center">
    <div class="row no-gutters align-items-start" >
       <div class="col col-lg-3">
<img src="https://velovita.com/wp-content/uploads/2024/05/bran-caramelMacchitato_Box_812x719-single-product.webp" class="icon-list" alt="..." style="max-width: 90px; border-radius: 50%;">
    </div>
        <div class="col-md px-0" >
 <h6 style="text-align: justify;" >List Number One</h6>
<p style="text-align: justify;" >Lorem ipsum dolor sit amet consectetur. Laoreet rhoncus faucibus aliquet faucibus aliquam nibh elementum nunc. Augue aenean egestas</p>
    </div>
    </div>
    </div>

    
<div class="container text-center">
    <div class="row no-gutters align-items-start" style="">
       <div class="col col-lg-3">
<img src="https://velovita.com/wp-content/uploads/2024/05/bran-caramelMacchitato_Box_812x719-single-product.webp" class="icon-list" alt="..." style="max-width: 90px; border-radius: 50%;">
    </div>
        <div class="col-md px-0" >
 <h6 style="text-align: justify;" >List Number Two</h6>
<p style="text-align: justify;" >Lorem ipsum dolor sit amet consectetur. Laoreet rhoncus faucibus aliquet faucibus aliquam nibh elementum nunc. Augue aenean egestas</p>
    </div>
    </div>
    </div>

<div class="container text-center">
    <div class="row no-gutters align-items-start" style="">
       <div class="col col-lg-3">
<img src="https://velovita.com/wp-content/uploads/2024/05/bran-caramelMacchitato_Box_812x719-single-product.webp" class="icon-list" alt="..." style="max-width: 90px; border-radius: 50%;">
    </div>
        <div class="col-md px-0" >
 <h6 style="text-align: justify;" >List Number Three</h6>
<p style="text-align: justify;" >Lorem ipsum dolor sit amet consectetur. Laoreet rhoncus faucibus aliquet faucibus aliquam nibh elementum nunc. Augue aenean egestas</p>
    </div>
    </div>
    </div>
    
    
    <div class="container text-center">
    <div class="row no-gutters align-items-start" style="">
       <div class="col col-lg-3">
<img src="https://velovita.com/wp-content/uploads/2024/05/bran-caramelMacchitato_Box_812x719-single-product.webp" class="icon-list" alt="..." style="max-width: 90px; border-radius: 50%;">
    </div>
        <div class="col-md px-0" >
 <h6 style="text-align: justify;" >List Number Four</h6>
<p style="text-align: justify;" >Lorem ipsum dolor sit amet consectetur. Laoreet rhoncus faucibus aliquet faucibus aliquam nibh elementum nunc. Augue aenean egestas</p>
    </div>
    </div>
    </div>

  </div>
  
</div>
  
  
  
  <div style="height: 50px"></div>

    <div class="row align-items-center justify-content-center">
    <div class="col-md custom-column">

    <div class="row align-items-start">
    <div class="col-md">
<img src="https://velovita.com/wp-content/uploads/2024/05/social-media-img_05.webp" class="img-fluid" alt="..." style="border-radius: 5%; width: 249px; height: 522px; object-fit: cover;">
    </div>
    <div class="col-md">
      <img src="https://velovita.com/wp-content/themes/velovita3-theme-prod-2024-05-05/assets/static/img/misc/lite-products-hero-2.webp" class="img-fluid" alt="..." style="border-radius: 5%; width: 249px; height: 249px; object-fit: cover; ">
         <br>
       <img src="https://velovita.com/wp-content/uploads/2024/05/byom-strawberry_Box_812x719-single-product.webp" class="img-fluid" alt="..." style="border-radius: 5%; width: 249px; height: 249px; object-fit: cover; ">
    </div>
    </div>
    
    </div>
    
    <div class="col-md custom-column">
 <h1 style="text-align: justify;">Headline of Website Will Goes Here in Two Line</h1>
<p style="text-align: justify;">Lorem ipsum dolor sit amet consectetur. Elementum risus tempor at vivamus curabitur viverra diam nec.</p>

<div class="container text-center">
    <div class="row no-gutters align-items-start" style="">
        <div class="col col-lg-2">
            <div style="width: 50px; height: 50px; background-color: #DF703D; border-radius: 50%;"></div>
        </div>
        <div class="col-md px-0" >
            <h6 style="text-align: justify;" >List Number One</h6>
            <p style="text-align: justify;" >Lorem ipsum dolor sit amet consectetur. Laoreet rhoncus faucibus aliquet faucibus aliquam nibh elementum nunc. Augue aenean egestas</p>
        </div>
    </div>
</div>

<div class="container text-center">
    <div class="row no-gutters align-items-start" style="">
        <div class="col col-lg-2">
            <div style="width: 50px; height: 50px; background-color: #DF703D; border-radius: 50%;"></div>
        </div>
        <div class="col-md px-0" >
            <h6 style="text-align: justify;" >List Number Two</h6>
            <p style="text-align: justify;" >Lorem ipsum dolor sit amet consectetur. Laoreet rhoncus faucibus aliquet faucibus aliquam nibh elementum nunc. Augue aenean egestas</p>
      <a>Link Button</a>
      
        </div>
    </div>
</div>

    </div>
    
    
    </div>
    
  
<div style="height: 50px"></div>


<div class="container text-center">
  <div class="row">
      <div class="col-4" style="text-align: justify;">
          <h1>Meet Our Team</h1>
          <h6>Lorem ipsum dolor sit amet consectetur. Elementum risus tempor at vivamus curabitur viverra diam nec.</h6>
          <a href="">Link Button</a>
      </div>
    <div class="col-8">
        
        <div id="carouselExampleIndicators" class="carousel slide">
  <div class="carousel-indicators">
    <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
    <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="1" aria-label="Slide 2"></button>
    <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="2" aria-label="Slide 3"></button>
  </div>
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="..." class="d-block w-100" alt="...">
    </div>
    <div class="carousel-item">
      <img src="..." class="d-block w-100" alt="...">
    </div>
    <div class="carousel-item">
      <img src="..." class="d-block w-100" alt="...">
    </div>
  </div>
  <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Previous</span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Next</span>
  </button>
</div>
        
        
    </div>
  </div>
</div>

<div style="height: 50px"></div>

<h1>
Headline of Website Will
Goes Here in Two Line
</h1>

<div class="container text-center">
  <div class="row" style="text-align: justify;">
    <div class="col"><div class="card" style="width: 18rem;">
  <img src="https://velovita.com/wp-content/uploads/2024/05/bran-model-products-page.webp" class="card-img-top" alt="...">
  <div class="card-body">
    <h5 class="card-title">List Number One</h5>
    <p class="card-text">Lorem ipsum dolor sit amet consectetur. Bibendum feugiat ipsum sodales at libero. In quis sed curabitur pretium.</p>
   
  </div>
</div></div>
    <div class="col"><div class="card" style="width: 18rem;">
  <img src="https://velovita.com/wp-content/uploads/2024/05/zlem-model-products-page.webp" class="card-img-top" alt="...">
  <div class="card-body">
    <h5 class="card-title">List Number Two</h5>
    <p class="card-text">Lorem ipsum dolor sit amet consectetur. Bibendum feugiat ipsum sodales at libero. In quis sed curabitur pretium.</p>
 
  </div>
</div></div>
    <div class="col"><div class="card" style="width: 18rem;">
  <img src="https://velovita.com/wp-content/uploads/2024/05/uuth-model-products-page.webp" class="card-img-top" alt="...">
  <div class="card-body">
    <h5 class="card-title">List Number Three</h5>
    <p class="card-text">Lorem ipsum dolor sit amet consectetur. Bibendum feugiat ipsum sodales at libero. In quis sed curabitur pretium.</p>
 
  </div>
</div></div>
    <div class="col"><div class="card" style="width: 18rem;">
  <img src="https://velovita.com/wp-content/uploads/2024/05/plos-model-products-page.webp" class="card-img-top" alt="...">
  <div class="card-body">
    <h5 class="card-title">List Number Four</h5>
    <p class="card-text">Lorem ipsum dolor sit amet consectetur. Bibendum feugiat ipsum sodales at libero. In quis sed curabitur pretium.</p>

  </div>
</div></div>
  </div>

</div>



  
<div style="height: 50px"></div>
 <h1>Blog</h1>
 <div style="height: 20px;"></div>

<?php
if (have_posts()) :
    while (have_posts()) : the_post();

        $custom_field_value = get_post_meta(get_the_ID(), '_custom_field_key', true);
        ?>
        <div class="post">
            <h2><?php the_title(); ?></h2>
            <div class="content">
                <?php the_content(); ?>
            </div>
            <?php if (!empty($custom_field_value)) : ?>
                <div class="custom-field-value">
                    <p>Custom Field Value: <?php echo esc_html($custom_field_value); ?></p>
                </div>
            <?php endif; ?>
        </div>
    <?php
    endwhile;
else :
    echo 'No hay contenido para mostrar.';
endif;
?>
<div style="height: 50px"></div>

<h2>Contact</h2>
    <form action="send.php" method="POST">
        <label for="nombre">Name:</label><br>
        <input type="text" id="nombre" name="nombre" required><br>
        <label for="email">Email:</label><br>
        <input type="email" id="email" name="email" required><br>
        <label for="mensaje">Mensage:</label><br>
        <textarea id="mensaje" name="mensaje" required></textarea><br>
        <input type="submit" value="Enviar">
    </form>
</main>

<?php
// Incluye el pie de página del sitio
get_footer();
?>
